import axios from 'axios';
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

export class ClientCodeClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getFile(body?: ICodeClientGetFileParams): Promise<void> {
    let url_ = this.baseUrl + '/api/Common/ClientCode/GetFile?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ICodeClientGetFileParams {
  module?: SahabModules;
}

export interface ICodeClientProcessGetFileDto {
  response: AxiosResponse;
}

export class CommonLookupsClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getList(body?: ICommonLookupsGetListParams): Promise<CommonLookupDto> {
    let url_ = this.baseUrl + '/api/Common/CommonLookups/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ICommonLookupsGetListParams {
  commonType?: CommonLookups;
  usingInFilter?: boolean;
}

export interface ICommonLookupsProcessGetListDto {
  response: AxiosResponse;
}

export class ExternalSystemClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getToUpdate(
    body?: IExternalSystemGetToUpdateParams,
  ): Promise<FullExternalSystemDto> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getById(body?: IExternalSystemGetByIdParams): Promise<ExternalSystemDto> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getPaginatedList(
    body?: IExternalSystemGetPaginatedListParams,
  ): Promise<ExternalSystemDtoIPaginatedList> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/GetPaginatedList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: IExternalSystemGetListParams): Promise<ExternalSystemDto[]> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/GetList';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: NewExternalSystemDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdateExternalSystemDto): Promise<UpdateExternalSystemDto> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: IExternalSystemDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/ExternalSystem/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IExternalSystemGetToUpdateParams {
  id?: number;
}

export interface IExternalSystemProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface IExternalSystemGetByIdParams {
  id?: number;
}

export interface IExternalSystemProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IExternalSystemGetPaginatedListParams {
  active?: boolean;
  pageIndex?: number;
  pageSize?: number;
}

export interface IExternalSystemProcessGetPaginatedListDto {
  response: AxiosResponse;
}

export interface IExternalSystemGetListParams {}

export interface IExternalSystemProcessGetListDto {
  response: AxiosResponse;
}

export interface IExternalSystemProcessCreateDto {
  response: AxiosResponse;
}

export interface IExternalSystemProcessUpdateDto {
  response: AxiosResponse;
}

export interface IExternalSystemProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface IExternalSystemDeleteParams {
  id?: number;
}

export interface IExternalSystemProcessDeleteDto {
  response: AxiosResponse;
}

export class JorCentralBankExportLogClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getById(
    body?: IJorCentralBankExportLogGetByIdParams,
  ): Promise<CentralBankExportLogDto> {
    let url_ = this.baseUrl + '/api/Common/JorCentralBankExportLog/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(
    body?: IJorCentralBankExportLogGetListParams,
  ): Promise<CentralBankExportLogListDto[]> {
    let url_ = this.baseUrl + '/api/Common/JorCentralBankExportLog/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IJorCentralBankExportLogGetByIdParams {
  id?: number;
}

export interface IJorCentralBankExportLogProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IJorCentralBankExportLogGetListParams {
  succeeded?: boolean;
  fileId?: number;
  fileName?: string;
  type?: ExportLogType;
  date_From?: string;
  date_To?: string;
  pageNumber?: number;
  pageSize?: number;
}

export interface IJorCentralBankExportLogProcessGetListDto {
  response: AxiosResponse;
}

export class JorCentralBankServiceClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  exportSendTransactions(body?: DateTimeRangeFilter): Promise<void> {
    let url_ =
      this.baseUrl + '/api/Common/JorCentralBankService/ExportSendTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  exportReceiveTransactions(body?: DateTimeRangeFilter): Promise<void> {
    let url_ =
      this.baseUrl +
      '/api/Common/JorCentralBankService/ExportReceiveTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  exportExchangeTransactions(body?: DateTimeRangeFilter): Promise<void> {
    let url_ =
      this.baseUrl +
      '/api/Common/JorCentralBankService/ExportExchangeTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IJorCentralBankServiceProcessExportSendTransactionsDto {
  response: AxiosResponse;
}

export interface IJorCentralBankServiceProcessExportReceiveTransactionsDto {
  response: AxiosResponse;
}

export interface IJorCentralBankServiceProcessExportExchangeTransactionsDto {
  response: AxiosResponse;
}

export class LookupCategoryClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getToUpdate(
    body?: ILookupCategoryGetToUpdateParams,
  ): Promise<FullLookupCategoryDto> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getById(body?: ILookupCategoryGetByIdParams): Promise<LookupCategoryDto> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getPaginatedList(
    body?: ILookupCategoryGetPaginatedListParams,
  ): Promise<LookupCategoryDtoIPaginatedList> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/GetPaginatedList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: ILookupCategoryGetListParams): Promise<LookupCategoryDto[]> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/GetList';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: NewLookupCategoryDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdateLookupCategoryDto): Promise<UpdateLookupCategoryDto> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: ILookupCategoryDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/LookupCategory/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ILookupCategoryGetToUpdateParams {
  id?: number;
}

export interface ILookupCategoryProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface ILookupCategoryGetByIdParams {
  id?: number;
}

export interface ILookupCategoryProcessGetByIdDto {
  response: AxiosResponse;
}

export interface ILookupCategoryGetPaginatedListParams {
  active?: boolean;
  pageIndex?: number;
  pageSize?: number;
}

export interface ILookupCategoryProcessGetPaginatedListDto {
  response: AxiosResponse;
}

export interface ILookupCategoryGetListParams {}

export interface ILookupCategoryProcessGetListDto {
  response: AxiosResponse;
}

export interface ILookupCategoryProcessCreateDto {
  response: AxiosResponse;
}

export interface ILookupCategoryProcessUpdateDto {
  response: AxiosResponse;
}

export interface ILookupCategoryProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface ILookupCategoryDeleteParams {
  id?: number;
}

export interface ILookupCategoryProcessDeleteDto {
  response: AxiosResponse;
}

export class LookupMappingClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getById(body?: ILookupMappingGetByIdParams): Promise<AddLookupMappingDto> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: ILookupMappingGetListParams): Promise<LookupMappingDto[]> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getExternal(body?: ILookupMappingGetExternalParams): Promise<ExternaItemDto> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/GetExternal?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getLocal(body?: ILookupMappingGetLocalParams): Promise<ExternaItemDto> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/GetLocal?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  seedData(body?: ILookupMappingSeedDataDto): Promise<ExternaItemDto> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/SeedData';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: AddLookupMappingDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdateLookupMappingDto): Promise<UpdateLookupMappingDto> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: ILookupMappingDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/LookupMapping/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ILookupMappingGetByIdParams {
  id?: number;
}

export interface ILookupMappingProcessGetByIdDto {
  response: AxiosResponse;
}

export interface ILookupMappingGetListParams {
  lookupCategoryId?: number;
  externalSystemId?: number;
}

export interface ILookupMappingProcessGetListDto {
  response: AxiosResponse;
}

export interface ILookupMappingGetExternalParams {
  lookupCategoryId?: number;
  localId?: number;
  externalSystemId?: number;
}

export interface ILookupMappingProcessGetExternalDto {
  response: AxiosResponse;
}

export interface ILookupMappingGetLocalParams {
  lookupCategoryId?: number;
  externalId?: string;
  externalSystemId?: number;
}

export interface ILookupMappingProcessGetLocalDto {
  response: AxiosResponse;
}

export interface ILookupMappingSeedDataDto {
  externalSystemId?: number;
  lookupCategoryId?: number;
  fileType?: LookupCategoryFileTypes;
  file?: FileParameter;
  externalIdConfiguration_Type?: MappingType;
  externalIdConfiguration_Key?: string;
  externalIdConfiguration_Index?: number;
  externalNameConfiguration_Type?: MappingType;
  externalNameConfiguration_Key?: string;
  externalNameConfiguration_Index?: number;
}

export interface ILookupMappingProcessSeedDataDto {
  response: AxiosResponse;
}

export interface ILookupMappingProcessCreateDto {
  response: AxiosResponse;
}

export interface ILookupMappingProcessUpdateDto {
  response: AxiosResponse;
}

export interface ILookupMappingProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface ILookupMappingDeleteParams {
  id?: number;
}

export interface ILookupMappingProcessDeleteDto {
  response: AxiosResponse;
}

export class PurposeClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getToUpdate(body?: IPurposeGetToUpdateParams): Promise<FullPurposeDto> {
    let url_ = this.baseUrl + '/api/Common/Purpose/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getById(body?: IPurposeGetByIdParams): Promise<PurposeDto> {
    let url_ = this.baseUrl + '/api/Common/Purpose/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getPaginatedList(
    body?: IPurposeGetPaginatedListParams,
  ): Promise<PurposeDtoIPaginatedList> {
    let url_ = this.baseUrl + '/api/Common/Purpose/GetPaginatedList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: IPurposeGetListParams): Promise<PurposeDto[]> {
    let url_ = this.baseUrl + '/api/Common/Purpose/GetList';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: NewPurposeDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/Purpose/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdatePurposeDto): Promise<UpdatePurposeDto> {
    let url_ = this.baseUrl + '/api/Common/Purpose/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/Purpose/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: IPurposeDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/Purpose/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IPurposeGetToUpdateParams {
  id?: number;
}

export interface IPurposeProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface IPurposeGetByIdParams {
  id?: number;
}

export interface IPurposeProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IPurposeGetPaginatedListParams {
  active?: boolean;
  pageIndex?: number;
  pageSize?: number;
}

export interface IPurposeProcessGetPaginatedListDto {
  response: AxiosResponse;
}

export interface IPurposeGetListParams {}

export interface IPurposeProcessGetListDto {
  response: AxiosResponse;
}

export interface IPurposeProcessCreateDto {
  response: AxiosResponse;
}

export interface IPurposeProcessUpdateDto {
  response: AxiosResponse;
}

export interface IPurposeProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface IPurposeDeleteParams {
  id?: number;
}

export interface IPurposeProcessDeleteDto {
  response: AxiosResponse;
}

export class RelationClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getToUpdate(body?: IRelationGetToUpdateParams): Promise<FullRelationDto> {
    let url_ = this.baseUrl + '/api/Common/Relation/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getById(body?: IRelationGetByIdParams): Promise<RelationDto> {
    let url_ = this.baseUrl + '/api/Common/Relation/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getPaginatedList(
    body?: IRelationGetPaginatedListParams,
  ): Promise<RelationDtoIPaginatedList> {
    let url_ = this.baseUrl + '/api/Common/Relation/GetPaginatedList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: IRelationGetListParams): Promise<RelationDto[]> {
    let url_ = this.baseUrl + '/api/Common/Relation/GetList';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: NewRelationDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/Relation/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdateRelationDto): Promise<UpdateRelationDto> {
    let url_ = this.baseUrl + '/api/Common/Relation/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/Relation/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: IRelationDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/Relation/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IRelationGetToUpdateParams {
  id?: number;
}

export interface IRelationProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface IRelationGetByIdParams {
  id?: number;
}

export interface IRelationProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IRelationGetPaginatedListParams {
  active?: boolean;
  pageIndex?: number;
  pageSize?: number;
}

export interface IRelationProcessGetPaginatedListDto {
  response: AxiosResponse;
}

export interface IRelationGetListParams {}

export interface IRelationProcessGetListDto {
  response: AxiosResponse;
}

export interface IRelationProcessCreateDto {
  response: AxiosResponse;
}

export interface IRelationProcessUpdateDto {
  response: AxiosResponse;
}

export interface IRelationProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface IRelationDeleteParams {
  id?: number;
}

export interface IRelationProcessDeleteDto {
  response: AxiosResponse;
}

export class SourceOfFundClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getToUpdate(
    body?: ISourceOfFundGetToUpdateParams,
  ): Promise<FullSourceOfFundDto> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getById(body?: ISourceOfFundGetByIdParams): Promise<SourceOfFundDto> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getPaginatedList(
    body?: ISourceOfFundGetPaginatedListParams,
  ): Promise<SourceOfFundDtoIPaginatedList> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/GetPaginatedList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(body?: ISourceOfFundGetListParams): Promise<SourceOfFundDto[]> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/GetList';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  create(body?: AddSourceOfFundDto): Promise<number> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/Create';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  update(body?: UpdateSourceOfFundDto): Promise<UpdateSourceOfFundDto> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/Update';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  changeStatus(body?: ChangeStatusModel): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/ChangeStatus';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  delete(body?: ISourceOfFundDeleteParams): Promise<boolean> {
    let url_ = this.baseUrl + '/api/Common/SourceOfFund/Delete?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'DELETE',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ISourceOfFundGetToUpdateParams {
  id?: number;
}

export interface ISourceOfFundProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface ISourceOfFundGetByIdParams {
  id?: number;
}

export interface ISourceOfFundProcessGetByIdDto {
  response: AxiosResponse;
}

export interface ISourceOfFundGetPaginatedListParams {
  active?: boolean;
  pageIndex?: number;
  pageSize?: number;
}

export interface ISourceOfFundProcessGetPaginatedListDto {
  response: AxiosResponse;
}

export interface ISourceOfFundGetListParams {}

export interface ISourceOfFundProcessGetListDto {
  response: AxiosResponse;
}

export interface ISourceOfFundProcessCreateDto {
  response: AxiosResponse;
}

export interface ISourceOfFundProcessUpdateDto {
  response: AxiosResponse;
}

export interface ISourceOfFundProcessChangeStatusDto {
  response: AxiosResponse;
}

export interface ISourceOfFundDeleteParams {
  id?: number;
}

export interface ISourceOfFundProcessDeleteDto {
  response: AxiosResponse;
}

export class TemplateResourcesClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getProfileCompanyLogo(
    body?: ITemplateResourcesGetProfileCompanyLogoParams,
  ): Promise<void> {
    let url_ =
      this.baseUrl + '/api/Common/TemplateResources/GetProfileCompanyLogo';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ITemplateResourcesGetProfileCompanyLogoParams {}

export interface ITemplateResourcesProcessGetProfileCompanyLogoDto {
  response: AxiosResponse;
}

export class UaeCentralBankSynchronizationClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  exportTransactions(
    body?: ExportTransactionsOptions,
  ): Promise<ExportTransactionsResultDto> {
    let url_ =
      this.baseUrl +
      '/api/Common/UaeCentralBankSynchronization/ExportTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  exportUpdatedTransactions(
    body?: ExportUpdatedTransactionsOptions,
  ): Promise<ExportTransactionsResultDto> {
    let url_ =
      this.baseUrl +
      '/api/Common/UaeCentralBankSynchronization/ExportUpdatedTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  importProcessedTransactions(
    body?: IUaeCentralBankSynchronizationImportProcessedTransactionsDto,
  ): Promise<void> {
    let url_ =
      this.baseUrl +
      '/api/Common/UaeCentralBankSynchronization/ImportProcessedTransactions';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'POST',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IUaeCentralBankSynchronizationProcessExportTransactionsDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankSynchronizationProcessExportUpdatedTransactionsDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankSynchronizationImportProcessedTransactionsDto {
  rTDOrRSUFile?: FileParameter;
  ackFile?: FileParameter;
  loadFromSftpServer?: boolean;
}

export interface IUaeCentralBankSynchronizationProcessImportProcessedTransactionsDto {
  response: AxiosResponse;
}

export class UaeCentralBankSynchronizationLogClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getById(
    body?: IUaeCentralBankSynchronizationLogGetByIdParams,
  ): Promise<CentralBankSynchronizationLogDto> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankSynchronizationLog/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(
    body?: IUaeCentralBankSynchronizationLogGetListParams,
  ): Promise<CentralBankSynchronizationLogListDto[]> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankSynchronizationLog/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IUaeCentralBankSynchronizationLogGetByIdParams {
  id?: number;
}

export interface IUaeCentralBankSynchronizationLogProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankSynchronizationLogGetListParams {
  succeed?: boolean;
  logFailType?: SynchronizationLogFailType;
  date_From?: string;
  date_To?: string;
  pageNumber?: number;
  pageSize?: number;
}

export interface IUaeCentralBankSynchronizationLogProcessGetListDto {
  response: AxiosResponse;
}

export class UaeCentralBankTransactionFileClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getById(
    body?: IUaeCentralBankTransactionFileGetByIdParams,
  ): Promise<CentralBankTransactionFileDto> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionFile/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(
    body?: IUaeCentralBankTransactionFileGetListParams,
  ): Promise<CentralBankTransactionFileListDto[]> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionFile/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IUaeCentralBankTransactionFileGetByIdParams {
  id?: number;
}

export interface IUaeCentralBankTransactionFileProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankTransactionFileGetListParams {
  succeed?: boolean;
  date_From?: string;
  date_To?: string;
  fileName?: string;
  processedDate?: string;
  processedByFileName?: string;
  pageNumber?: number;
  pageSize?: number;
}

export interface IUaeCentralBankTransactionFileProcessGetListDto {
  response: AxiosResponse;
}

export class UaeCentralBankTransactionLogClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getById(
    body?: IUaeCentralBankTransactionLogGetByIdParams,
  ): Promise<CentralBankTransactionLogDto> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionLog/GetById?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getList(
    body?: IUaeCentralBankTransactionLogGetListParams,
  ): Promise<CentralBankTransactionLogListDto[]> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionLog/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  closed(body?: IUaeCentralBankTransactionLogClosedDto): Promise<void> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionLog/Closed?';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  pending(body?: IUaeCentralBankTransactionLogPendingDto): Promise<void> {
    let url_ =
      this.baseUrl + '/api/Common/UaeCentralBankTransactionLog/Pending?';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IUaeCentralBankTransactionLogGetByIdParams {
  id?: number;
}

export interface IUaeCentralBankTransactionLogProcessGetByIdDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankTransactionLogGetListParams {
  transactionType?: TransactionTypes;
  transactionId?: number;
  lineNumber?: string;
  type?: TransactionLogType;
  transactionLogProcessingStatuses?: TransactionLogProcessingStatuses;
  centralBankTransactionFileId?: number;
  date_From?: string;
  date_To?: string;
  pageNumber?: number;
  pageSize?: number;
}

export interface IUaeCentralBankTransactionLogProcessGetListDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankTransactionLogClosedDto {
  id?: number;
}

export interface IUaeCentralBankTransactionLogProcessClosedDto {
  response: AxiosResponse;
}

export interface IUaeCentralBankTransactionLogPendingDto {
  id?: number;
}

export interface IUaeCentralBankTransactionLogProcessPendingDto {
  response: AxiosResponse;
}

export class ApiException {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  isApiException(body: IApiExceptionIsApiExceptionDto): obj is ApiException {
    let url_ = this.baseUrl + '';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'Unknown',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IApiExceptionIsApiExceptionDto {
  obj: any;
}

export interface AddLookupMappingDto {
  externalSystemId: number;
  lookupCategoryId: number;
  externalId: string;
  externalName: string;
  localId: number;
}
export interface AddSourceOfFundDto {
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface CentralBankExportLogDto {
  id: number;
  succeeded: boolean;
  from?: string;
  to?: string;
  failReasons?: string[];
  fileId?: number;
  fileName?: string;
  file: FileDto;
  type: ExportLogType;
}
export interface CentralBankExportLogListDto {
  id: number;
  succeeded: boolean;
  from?: string;
  to?: string;
  failReasons?: string[];
  fileId?: number;
  fileName?: string;
  file: FileDto;
  type: ExportLogType;
}
export interface CentralBankSynchronizationLogDto {
  id: number;
  succeeded: boolean;
  notes?: string[];
  startDate: string;
  finishDate: string;
  logFailType: SynchronizationLogFailType;
  operationType?: string;
  created: string;
  lastModified?: string;
}
export interface CentralBankSynchronizationLogListDto {
  id: number;
  succeeded: boolean;
  notes?: string[];
  startDate: string;
  finishDate: string;
  logFailType: SynchronizationLogFailType;
  operationType?: string;
  created: string;
  lastModified?: string;
}
export interface CentralBankTransactionFileDto {
  id: number;
  file: FileDto;
  fileId: number;
  fileName?: string;
  mappedRecordsCount: number;
  unMappedRecordsCount: number;
  lastProcessedSendTransactionId?: number;
  lastProcessedReceiveTransactionId?: number;
  succeeded: boolean;
  processedDate?: string;
  type: TransactionFileLogType;
  processedByFileName?: string;
  created: string;
  lastModified?: string;
  details?: CentralBankTransactionLogListDto[];
}
export interface CentralBankTransactionFileListDto {
  id: number;
  file: FileDto;
  fileId: number;
  fileName?: string;
  mappedRecordsCount: number;
  unMappedRecordsCount: number;
  lastProcessedSendTransactionId?: number;
  lastProcessedReceiveTransactionId?: number;
  succeeded: boolean;
  processedDate?: string;
  type: TransactionFileLogType;
  processedByFileName?: string;
  created: string;
  lastModified?: string;
}
export interface CentralBankTransactionLogDto {
  id: number;
  transactionType: TransactionTypes;
  transactionId: number;
  lineNumber?: string;
  type: TransactionLogType;
  transactionLogProcessingStatuses: TransactionLogProcessingStatuses;
  actionType: ActionType;
  actionName?: string;
  failReasons?: string[];
  created: string;
  lastModified?: string;
  centralBankTransactionFileName?: string;
  centralBankTransactionFileId?: number;
  updateLogParent: CentralBankTransactionLogDto;
  updateLogParentId?: number;
}
export interface CentralBankTransactionLogListDto {
  id: number;
  transactionType: TransactionTypes;
  transactionId: number;
  lineNumber?: string;
  type: TransactionLogType;
  transactionLogProcessingStatuses: TransactionLogProcessingStatuses;
  actionType: ActionType;
  actionName?: string;
  failReasons?: string[];
  created: string;
  lastModified?: string;
  centralBankTransactionFileName?: string;
  centralBankTransactionFileId?: number;
  updateLogParent: CentralBankTransactionLogDto;
  updateLogParentId?: number;
}
export interface ChangeStatusModel {
  ids: number[];
  active: boolean;
  reason?: string;
}
export interface CommonLookupDto {
  data?: any[];
}
export interface DateTimeRangeFilter {
  from: string;
  to: string;
}
export interface ExportTransactionsOptions {
  recordsPerFile?: number;
  exportTransactionsType: ExportTransactionsType;
}
export interface ExportTransactionsResultDto {
  file: FileDto;
  failRecordsCount: number;
  mappedRecordsCount: number;
  unMappedTransactions?: RecordMappingResult[];
}
export interface ExportUpdatedTransactionsOptions {}
export interface ExternaItemDto {
  id?: string;
  name?: string;
}
export interface ExternalSystemDto {
  id: number;
  name?: string;
  description?: string;
  active: boolean;
}
export interface ExternalSystemDtoIPaginatedList {
  readonly items?: ExternalSystemDto[];
  readonly pageNumber: number;
  readonly totalPages: number;
  readonly totalCount: number;
  readonly hasPreviousPage: boolean;
  readonly hasNextPage: boolean;
}
export interface FileDto {
  id: number;
  name?: string;
  extension?: string;
  link?: string;
  created: string;
}
export interface FullExternalSystemDto {
  id: number;
  name?: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface FullLookupCategoryDto {
  id: number;
  name?: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
  type: LookupCategoryDataTypes;
}
export interface FullPurposeDto {
  id: number;
  name?: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface FullRelationDto {
  id: number;
  name?: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface FullSourceOfFundDto {
  id: number;
  name?: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface LookupCategoryDto {
  id: number;
  name?: string;
  description?: string;
  active: boolean;
  type: LookupCategoryDataTypes;
}
export interface LookupCategoryDtoIPaginatedList {
  readonly items?: LookupCategoryDto[];
  readonly pageNumber: number;
  readonly totalPages: number;
  readonly totalCount: number;
  readonly hasPreviousPage: boolean;
  readonly hasNextPage: boolean;
}
export interface LookupMappingDto {
  id: number;
  externalSystem: ExternalSystemDto;
  lookupCategory: LookupCategoryDto;
  externalId?: string;
  externalName?: string;
  localId: number;
}
export interface NewExternalSystemDto {
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface NewLookupCategoryDto {
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
  type: LookupCategoryDataTypes;
}
export interface NewPurposeDto {
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface NewRelationDto {
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface PurposeDto {
  id: number;
  name?: string;
  description?: string;
  active: boolean;
}
export interface PurposeDtoIPaginatedList {
  readonly items?: PurposeDto[];
  readonly pageNumber: number;
  readonly totalPages: number;
  readonly totalCount: number;
  readonly hasPreviousPage: boolean;
  readonly hasNextPage: boolean;
}
export interface RecordMappingResult {
  succeed: boolean;
  transactionId?: number;
  transactionNumber?: string;
  transactionType: TransactionTypes;
  reasons?: string[];
}
export interface RelationDto {
  id: number;
  name?: string;
  description?: string;
  active: boolean;
}
export interface RelationDtoIPaginatedList {
  readonly items?: RelationDto[];
  readonly pageNumber: number;
  readonly totalPages: number;
  readonly totalCount: number;
  readonly hasPreviousPage: boolean;
  readonly hasNextPage: boolean;
}
export interface SourceOfFundDto {
  id: number;
  name?: string;
  description?: string;
  active: boolean;
}
export interface SourceOfFundDtoIPaginatedList {
  readonly items?: SourceOfFundDto[];
  readonly pageNumber: number;
  readonly totalPages: number;
  readonly totalCount: number;
  readonly hasPreviousPage: boolean;
  readonly hasNextPage: boolean;
}
export interface UpdateExternalSystemDto {
  id: number;
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface UpdateLookupCategoryDto {
  id: number;
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
  type: LookupCategoryDataTypes;
}
export interface UpdateLookupMappingDto {
  id: number;
  externalSystemId: number;
  lookupCategoryId: number;
  externalId: string;
  externalName: string;
  localId: number;
}
export interface UpdatePurposeDto {
  id: number;
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface UpdateRelationDto {
  id: number;
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface UpdateSourceOfFundDto {
  id: number;
  name: string;
  nameLang?: string;
  description?: string;
  descriptionLang?: string;
}
export interface FileParameter {
  data: any;
  fileName: string;
}

export enum ActionType {
  RTD = 'RTD',
  RSU = 'RSU',
}

export enum CommonLookups {
  Purpose = 'Purpose',
  SourceOfFund = 'SourceOfFund',
  TransactionType = 'TransactionType',
}

export enum ExportLogType {
  SendTransactions = 'SendTransactions',
  ReceiveTransactions = 'ReceiveTransactions',
  Exchange = 'Exchange',
}

export enum ExportTransactionsType {
  NewTransactions = 'NewTransactions',
  NewTransactionsAndWaitingForAcknowledgment = 'NewTransactionsAndWaitingForAcknowledgment',
}

export enum LookupCategoryDataTypes {
  Country = 'Country',
  CustomerSubType = 'CustomerSubType',
  Purpose = 'Purpose',
  Currency = 'Currency',
  SourceOfFund = 'SourceOfFund',
  DeliveryMethod = 'DeliveryMethod',
  Relation = 'Relation',
  IdentityType = 'IdentityType',
  Activity = 'Activity',
  AddressType = 'AddressType',
  DelegationType = 'DelegationType',
  Gender = 'Gender',
  Industry = 'Industry',
  LiabilityType = 'LiabilityType',
  OwnershipType = 'OwnershipType',
  PartnershipType = 'PartnershipType',
  Profession = 'Profession',
  ResidencyType = 'ResidencyType',
  Branch = 'Branch',
  City = 'City',
  Text = 'Text',
  Provider = 'Provider',
  ProviderProfile = 'ProviderProfile',
  Number = 'Number',
  Decimal = 'Decimal',
}

export enum LookupCategoryFileTypes {
  XML = 'XML',
  Excel = 'Excel',
  CSV = 'CSV',
  Json = 'Json',
}

export enum MappingType {
  Key = 'Key',
  Index = 'Index',
}

export enum SahabModules {
  Common = 'Common',
  Customer = 'Customer',
  FCExchange = 'FCExchange',
  Finance = 'Finance',
  EntityManagement = 'EntityManagement',
  Compliance = 'Compliance',
  Utilities = 'Utilities',
  Remittance = 'Remittance',
  Accounting = 'Accounting',
  SystemSettings = 'SystemSettings',
}

export enum SynchronizationLogFailType {
  Configurations = 'Configurations',
  Connection = 'Connection',
  Validation = 'Validation',
}

export enum TransactionFileLogType {
  CentralBank = 'CentralBank',
}

export enum TransactionLogProcessingStatuses {
  Pending = 'Pending',
  WaitingForAcknowledgment = 'WaitingForAcknowledgment',
  Succeeded = 'Succeeded',
  Failed = 'Failed',
  Closed = 'Closed',
}

export enum TransactionLogType {
  CentralBank = 'CentralBank',
  Validation = 'Validation',
}

export enum TransactionTypes {
  FC_Sale = 'FC_Sale',
  FC_Purchase = 'FC_Purchase',
  SendMoney = 'SendMoney',
  ReceiveMoney = 'ReceiveMoney',
  Income = 'Income',
  Expenses = 'Expenses',
  InternalTransfer = 'InternalTransfer',
  ExternalTransfer = 'ExternalTransfer',
  StockTransaction = 'StockTransaction',
}
function process(response: AxiosResponse) {
  try {
    const res = JSON.parse(response.data);
    return Promise.resolve(res);
  } catch (e) {
    return Promise.resolve(response.data);
  }
}

function objectToFormData(obj: { [key: string]: any }, rootName?: string) {
  const formData = new FormData();
  function appendFormData(data: { [key: string]: any } | any, root?: string) {
    root = root || '';
    if (root.includes('_')) {
      const roots = root.split('_');
      root = roots.map((r) => toUpperCamelCase(r)).join('.');
    }

    if (isFile(data)) {
      if (data instanceof File) {
        formData.append(root, data, data.name);
      }
      if ('data' in data && data.data instanceof File) {
        formData.append(root, data.data, data.data.name);
      }
    } else if (Array.isArray(data)) {
      for (let i = 0; i < data.length; i++) {
        if (isFile(data[i])) {
          appendFormData(data[i], root);
        } else {
          appendFormData(data[i], `${root}[${i}]`);
        }
      }
    } else if (typeof data === 'object' && data) {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          if (root === '') {
            appendFormData(data[key], toUpperCamelCase(key));
          } else {
            appendFormData(
              data[key],
              `${toUpperCamelCase(root)}.${toUpperCamelCase(key)}`,
            );
          }
        }
      }
    } else {
      if (data != null) {
        formData.append(root, data.toString());
      }
    }
  }

  appendFormData(obj, rootName);

  return formData;
}

function toUpperCamelCase(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function isFile(data: any) {
  if (!data) return false;
  if (typeof data !== 'object') return false;

  return data instanceof File || ('data' in data && data.data instanceof File);
}

function addQueryParamsToUrl(url: string, params: any) {
  const url_ = new URL(url);

  function addParam(key: string, value: any) {
    if (value == undefined) return;

    if (key.includes('_')) {
      const [key1, key2] = key.split('_');
      key = `${toUpperCamelCase(key1)}.${toUpperCamelCase(key2)}`;
    }

    if (Array.isArray(value)) {
      value.forEach((item) => addParam(key, item));
    } else if (typeof value === 'object') {
      for (const [subKey, subValue] of Object.entries(value)) {
        addParam(`${key}.${subKey}`, subValue);
      }
    } else {
      url_.searchParams.append(toUpperCamelCase(key), value.toString());
    }
  }

  if (params == undefined) return url_.toString();

  for (const [key, value] of Object.entries(params)) {
    addParam(key, value);
  }

  return url_.toString();
}
