import axios from 'axios';
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';

export class SystemSettingsClient {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  getList(body?: ISystemSettingsGetListParams): Promise<SystemSettingDto[]> {
    let url_ = this.baseUrl + '/api/SystemSettings/SystemSettings/GetList?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getToUpdate(
    body?: ISystemSettingsGetToUpdateParams,
  ): Promise<SystemSettingForUpdateDto> {
    let url_ = this.baseUrl + '/api/SystemSettings/SystemSettings/GetToUpdate?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  updateValue(body?: UpdateSettingModel): Promise<void> {
    let url_ = this.baseUrl + '/api/SystemSettings/SystemSettings/UpdateValue';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'PUT',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }

  getSettingValueByKey(
    body?: ISystemSettingsGetSettingValueByKeyParams,
  ): Promise<string> {
    let url_ =
      this.baseUrl + '/api/SystemSettings/SystemSettings/GetSettingValueByKey?';
    url_ = addQueryParamsToUrl(url_, body);

    let options_: AxiosRequestConfig = {
      method: 'GET',
      url: url_,
      headers: {
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface ISystemSettingsGetListParams {
  group?: string;
}

export interface ISystemSettingsProcessGetListDto {
  response: AxiosResponse;
}

export interface ISystemSettingsGetToUpdateParams {
  id?: number;
}

export interface ISystemSettingsProcessGetToUpdateDto {
  response: AxiosResponse;
}

export interface ISystemSettingsProcessUpdateValueDto {
  response: AxiosResponse;
}

export interface ISystemSettingsGetSettingValueByKeyParams {
  key?: string;
}

export interface ISystemSettingsProcessGetSettingValueByKeyDto {
  response: AxiosResponse;
}

export class ApiException {
  protected instance: AxiosInstance;
  protected baseUrl: string;

  constructor(baseUrl?: string, instance?: AxiosInstance) {
    this.instance = instance || axios.create();

    this.baseUrl = baseUrl ?? '';
  }

  isApiException(body: IApiExceptionIsApiExceptionDto): obj is ApiException {
    let url_ = this.baseUrl + '';
    url_ = url_.replace(/[?&]$/, '');

    const content_ = JSON.stringify(body);

    let options_: AxiosRequestConfig = {
      data: content_,
      method: 'Unknown',
      url: url_,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'text/plain',
      },
    };

    return this.instance.request(options_).then(process);
  }
}

export interface IApiExceptionIsApiExceptionDto {
  obj: any;
}

export interface SystemSettingDto {
  id: number;
  displayOrder: number;
  name?: string;
  key?: string;
  value?: string;
  group?: string;
  dataType: DataTypes;
  description?: string;
  isSystemControlled: boolean;
  valuesList?: string[];
}
export interface SystemSettingForUpdateDto {
  id: number;
  displayOrder: number;
  name?: string;
  nameLang?: string;
  key?: string;
  value?: string;
  group?: string;
  dataType: DataTypes;
  description?: string;
  descriptionLang?: string;
  valuesList?: string[];
}
export interface UpdateSettingModel {
  id: number;
  value?: string;
}

export enum DataTypes {
  Text = 'Text',
  TextArea = 'TextArea',
  SecureText = 'SecureText',
  Number = 'Number',
  Decimal = 'Decimal',
  Percentage = 'Percentage',
  DateOnly = 'DateOnly',
  TimeOnly = 'TimeOnly',
  DateTime = 'DateTime',
  ScreeningResult = 'ScreeningResult',
  Boolean = 'Boolean',
  CustomLookup = 'CustomLookup',
  Country = 'Country',
  CustomerType = 'CustomerType',
  CustomerSubType = 'CustomerSubType',
  Purpose = 'Purpose',
  Currency = 'Currency',
  Activity = 'Activity',
  Nationality = 'Nationality',
  IdentityType = 'IdentityType',
  SourceOfFund = 'SourceOfFund',
  DeliveryMethod = 'DeliveryMethod',
  Relation = 'Relation',
  AddressType = 'AddressType',
  DelegationType = 'DelegationType',
  Gender = 'Gender',
  Industry = 'Industry',
  LiabilityType = 'LiabilityType',
  OwnershipType = 'OwnershipType',
  PartnershipType = 'PartnershipType',
  Profession = 'Profession',
  ResidencyType = 'ResidencyType',
  Product = 'Product',
  CustomerStatus = 'CustomerStatus',
  Channel = 'Channel',
  PaymentMode = 'PaymentMode',
  Account = 'Account',
  AggregateAccount = 'AggregateAccount',
  JournalAccount = 'JournalAccount',
}
function process(response: AxiosResponse) {
  try {
    const res = JSON.parse(response.data);
    return Promise.resolve(res);
  } catch (e) {
    return Promise.resolve(response.data);
  }
}

function objectToFormData(obj: { [key: string]: any }, rootName?: string) {
  const formData = new FormData();
  function appendFormData(data: { [key: string]: any } | any, root?: string) {
    root = root || '';
    if (root.includes('_')) {
      const roots = root.split('_');
      root = roots.map((r) => toUpperCamelCase(r)).join('.');
    }

    if (isFile(data)) {
      if (data instanceof File) {
        formData.append(root, data, data.name);
      }
      if ('data' in data && data.data instanceof File) {
        formData.append(root, data.data, data.data.name);
      }
    } else if (Array.isArray(data)) {
      for (let i = 0; i < data.length; i++) {
        if (isFile(data[i])) {
          appendFormData(data[i], root);
        } else {
          appendFormData(data[i], `${root}[${i}]`);
        }
      }
    } else if (typeof data === 'object' && data) {
      for (const key in data) {
        if (data.hasOwnProperty(key)) {
          if (root === '') {
            appendFormData(data[key], toUpperCamelCase(key));
          } else {
            appendFormData(
              data[key],
              `${toUpperCamelCase(root)}.${toUpperCamelCase(key)}`,
            );
          }
        }
      }
    } else {
      if (data != null) {
        formData.append(root, data.toString());
      }
    }
  }

  appendFormData(obj, rootName);

  return formData;
}

function toUpperCamelCase(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function isFile(data: any) {
  if (!data) return false;
  if (typeof data !== 'object') return false;

  return data instanceof File || ('data' in data && data.data instanceof File);
}

function addQueryParamsToUrl(url: string, params: any) {
  const url_ = new URL(url);

  function addParam(key: string, value: any) {
    if (value == undefined) return;

    if (key.includes('_')) {
      const [key1, key2] = key.split('_');
      key = `${toUpperCamelCase(key1)}.${toUpperCamelCase(key2)}`;
    }

    if (Array.isArray(value)) {
      value.forEach((item) => addParam(key, item));
    } else if (typeof value === 'object') {
      for (const [subKey, subValue] of Object.entries(value)) {
        addParam(`${key}.${subKey}`, subValue);
      }
    } else {
      url_.searchParams.append(toUpperCamelCase(key), value.toString());
    }
  }

  if (params == undefined) return url_.toString();

  for (const [key, value] of Object.entries(params)) {
    addParam(key, value);
  }

  return url_.toString();
}
